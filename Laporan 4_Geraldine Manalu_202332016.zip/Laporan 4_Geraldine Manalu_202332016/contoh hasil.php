<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Penilaian Mahasiswa</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>

    <style>
        body {
            background-color: #f8f9fa;
        }
        .card-header {
            background-color: #007bff;
            color: white;
            text-align: center; /* Tengah untuk judul */
        }
        .form-label {
            font-weight: bold;
        }
        #submitBtn {
            display: block;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="container mt-4 mb-5 px-5">
        <div class="card shadow-sm" id="resultCard">
            <div class="card-header">Form Penilaian Mahasiswa</div>
            <div class="card-body">
                <!-- Form input nilai -->
                <form id="nilaiForm">
                    <div class="mb-3">
                        <label class="form-label">Masukkan Nama</label>
                        <input type="text" class="form-control" id="nama" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Masukkan NIM</label>
                        <input type="text" class="form-control" id="nim" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Nilai Kehadiran (10%)</label>
                        <input type="number" class="form-control" id="kehadiran" min="0" max="100" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Nilai Tugas (20%)</label>
                        <input type="number" class="form-control" id="tugas" min="0" max="100" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Nilai UTS (30%)</label>
                        <input type="number" class="form-control" id="uts" min="0" max="100" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Nilai UAS (40%)</label>
                        <input type="number" class="form-control" id="uas" min="0" max="100" required>
                    </div>
                    <button type="submit" class="btn btn-primary" id="submitBtn">Proses</button>
                </form>
                <!-- Hasil akan ditampilkan di sini -->
                <div class="mt-4" id="hasil"></div>
            </div>
        </div>
    </div>

<script>
// Menangani form saat disubmit
 document.getElementById("nilaiForm").addEventListener("submit", function(e) {
    e.preventDefault(); // Mencegah reload

    // Mengambil nilai input
    let nama = document.getElementById("nama").value;
    let nim = document.getElementById("nim").value;
    let absen = parseFloat(document.getElementById("kehadiran").value);
    let tugas = parseFloat(document.getElementById("tugas").value);
    let uts = parseFloat(document.getElementById("uts").value);
    let uas = parseFloat(document.getElementById("uas").value);

    // Hitung nilai akhir
    let nilaiAkhir = absen * 0.1 + tugas * 0.2 + uts * 0.3 + uas * 0.4;

    // Tentukan grade
    let grade = "";
    if (nilaiAkhir >= 85) grade = "A";
    else if (nilaiAkhir >= 70) grade = "B";
    else if (nilaiAkhir >= 55) grade = "C";
    else if (nilaiAkhir >= 40) grade = "D";
    else grade = "E";

    // Tentukan kelulusan
    let lulus = false;
    if (absen < 70) {
        lulus = false;
    } else if (nilaiAkhir >= 60 && absen > 70 && tugas >= 40 && uts >= 40 && uas >= 40) {
        lulus = true;
    }

    // Update warna card dan tombol
    let card = document.getElementById("resultCard");
    let tombol = document.getElementById("submitBtn");

    if (lulus) {
        card.classList.remove("border-danger");
        card.classList.add("border-success");
        tombol.classList.remove("btn-danger");
        tombol.classList.add("btn-success");
    } else {
        card.classList.remove("border-success");
        card.classList.add("border-danger");
        tombol.classList.remove("btn-success");
        tombol.classList.add("btn-danger");
    }

    // Tampilkan hasil
    document.getElementById("hasil").innerHTML = `
        <div class="alert ${lulus ? 'alert-success' : 'alert-danger'}">
            <strong>Nama:</strong> ${nama}<br>
            <strong>NIM:</strong> ${nim}<br>
            <strong>Nilai Akhir:</strong> ${nilaiAkhir.toFixed(2)}<br>
            <strong>Grade:</strong> ${grade}<br>
            <strong>Status:</strong> ${lulus ? 'LULUS' : 'TIDAK LULUS'}
        </div>
    `;
 });
</script>
</body>
</html>
